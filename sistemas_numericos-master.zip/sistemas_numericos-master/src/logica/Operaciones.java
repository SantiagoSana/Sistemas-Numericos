/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package logica;

/**
 *
 * @author Vinni
 */
public class Operaciones {
    
    public String convertirDecimalBinario(String valor){
        String nuevoNumero = "1000";
        
        return nuevoNumero;
    }
    public String convertirDecimalHexadecimal(String valor){
        return "";
    }
    public String convertirDecimalOctal(String valor){
        return "";
    }
    public String convertirBinarioDecimal(String valor){
        return "";
    }
    public String convertirBinarioHexadecimal(String valor){
        return "";
    }
    public String convertirBinarioOctal(String valor){
        return "";
    }
    public String convertirHexadecimalBinario(String valor){
        return "";
    }
    public String convertirHexadecimalDecimal(String valor){
        return "";
    }
    public String convertirHexadecimalOctal(String valor){
        return "";
    }
    public String convertirOctalBinario(String valor){
        return "";
    }
    public String convertirOctalDecimal(String valor){
        return "";
    }
    public String convertirOctalHexadecimal(String valor){
        return "";
    }
    
}
